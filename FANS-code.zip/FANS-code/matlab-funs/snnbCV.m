% This function implements the sparse nonparametric naive bayes cross validation
% x: n*p matrix
% y: label for the data, 0/1 or 1/2
% Id: importance ranking for the features

function [fitCV] = snnbCV(fit)
%
Id = fit.IdDetail;
%Id = fit.IdLik;
nfold = fit.nfold;
logDen = fit.logDen;

p = fit.p;



errorCV = zeros(1,p); %%%cv classification error
errorDis = zeros(1,p); %%distance to true
logLikRatio = zeros(1,p); %%%Calculate the log-likelihood-ratio
for i=1:nfold
    display(['CV ', num2str(i), ' of ', num2str(nfold)]);   
    [logDen1]=logDen{i}{1};
    [logDen2]=logDen{i}{2};
    [logDen3]=logDen{i}{3};
    [logDen4]=logDen{i}{4};
    logDen1 = cumsum(logDen1(:,Id),2);
    logDen2 = cumsum(logDen2(:,Id),2);
    logDen3 = cumsum(logDen3(:,Id),2);
    logDen4 = cumsum(logDen4(:,Id),2);    
    errorPred = [logDen1<logDen3; logDen2>logDen4];    
    dist = [(logDen3-logDen1).*(logDen1<logDen3); (logDen2-logDen4).*(logDen2>logDen4)];

    logRatio = -[logDen1-logDen3; logDen4-logDen2];
    
    logLikRatio = logLikRatio + sum(logRatio);
    errorDis = errorDis + sum(dist);
    errorCV = errorCV + sum(errorPred);
end
errorCVDetail = errorCV + errorDis/max(errorDis); %%added the distance for the wrong classification to differentiate the draw situations
%errorCVDetail = errorCV + logLikRatio/3/max(abs(logLikRatio));

[~, fitCV.ind] = min(errorCV);
[~, fitCV.indDetail] = min(errorCVDetail);
[~, fitCV.indLik] =  min(logLikRatio);

fitCV.errorCV = errorCV;
fitCV.errorCVDetail = errorCVDetail;
fitCV.IdDetail = fit.IdDetail;
fitCV.IdLik = fit.IdLik;
fitCV.pnum =fit.pnum;
fitCV.logLikRatio = logLikRatio;
%[~, indLik] = min(errorCVDetail2);

%class = (x-repmat(fit.mua', n, 1))*fitCV.w>0;
%fitCV.error = mean(class+1~=y);






















