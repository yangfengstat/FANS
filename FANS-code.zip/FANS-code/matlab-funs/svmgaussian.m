function [label, error]=svmgaussian(x,y,xtest,ytest)
[x_scaled,scale_factor] = mapminmax(x');   

[bestc, bestg, ~, ~] = modsel(y,x_scaled');
cmd = [' -c ',num2str(bestc),' -g ',num2str(bestg),' -q'];

fit = svmtrain(y,x_scaled',cmd);

xtest_scaled = mapminmax('apply',xtest',scale_factor);

[label, accuracy, ~] = svmpredict(ytest, xtest_scaled', fit);
error = 1-accuracy(1)/100;
