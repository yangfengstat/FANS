% This function implements the nonparametric naive bayes cross validation
% x: n*p matrix
% y: label for the data, 0/1 or 1/2


function [fit] = nnbCV(x, y, nfold, pnum)

if (nargin<3 )
    nfold = 5;
end
if (nargin<4)
    pnum = 2^10;
end


[n, p] = size(x);

if(min(y)==1) %%%if y=1/2, change it to 0/1
    y = y - 1;
end

x1 = x(y==0,:);  
x2 = x(y==1,:);
%%% seperate the class 0 and class 1
n1 = size(x1,1);
n2 = n-n1;


rand('state', 0);
randn('state',0);

indices1  = crossvalind('Kfold',n1, nfold);
indices2  = crossvalind('Kfold',n2, nfold);



errorCV = zeros(1,p); %%%cv classification error
errorDis = zeros(1,p); %%distance to true
logLikRatio = zeros(1,p); %%%Calculate the log-likelihood-ratio
for i=1:nfold
    display(['CV ', num2str(i), ' of ', num2str(nfold)]);
    test1 = (indices1==i);
    test2 = (indices2==i);
    train1 = ~test1;
    train2 = ~test2;
    x1train = x1(train1,:);
    x2train = x2(train2,:);
    x1test = x1(test1,:);
    x2test = x2(test2,:);
    n1test = size(x1test, 1);
    n2test = size(x2test, 1);
    n1train = n1-n1test;
    n2train = n2-n2test;
    
    [den1,xmesh1] = Mkde(x1train,pnum);
    [den2,xmesh2] = Mkde(x2train,pnum);
    [logDen1]=logdenIndPred(den1,xmesh1,x1test);
    [logDen2]=logdenIndPred(den1,xmesh1,x2test);
    [logDen3]=logdenIndPred(den2,xmesh2,x1test);
    [logDen4]=logdenIndPred(den2,xmesh2,x2test);
    errorPred = [logDen1<logDen3; logDen2>logDen4];
    dist = [(logDen3-logDen1).*(logDen1<logDen3); (logDen2-logDen4).*(logDen2>logDen4)];
    logRatio = -[logDen1-logDen3; logDen4-logDen2];
    errorDis = errorDis + sum(dist);
    errorCV = errorCV + sum(errorPred);
    logLikRatio = logLikRatio + sum(logRatio);
    logDen{i}{1} = logDen1;
    logDen{i}{2} = logDen2;
    logDen{i}{3} = logDen3;
    logDen{i}{4} = logDen4;
end
errorCVDetail = errorCV + errorDis/max(errorDis); %%added the distance for the wrong classification to differentiate the draw situations
%errorCVDetail = errorCV + logLikRatio/3/max(abs(logLikRatio));
[~, Id] = sort(errorCV);
[~, IdDetail] = sort(errorCVDetail);
[~, IdLik] = sort(logLikRatio);

fit.nfold = nfold;
fit.logDen = logDen;
fit.Id = Id;
fit.IdLik = IdLik;
fit.IdDetail = IdDetail;
fit.p = p;
fit.errorCVDetail=errorCVDetail;
fit.errorCV=errorCV;
fit.pnum=pnum;
%fit.errorCVDetail2=errorCVDetail2;
%class = (x-repmat(fit.mua', n, 1))*fitCV.w>0;
%fitCV.error = mean(class+1~=y);






















