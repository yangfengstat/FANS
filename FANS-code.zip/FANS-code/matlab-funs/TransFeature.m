function [xn] = TransFeature(xtest,fit)

logDen1 = logdenIndPred(fit.den1,fit.xmesh1,xtest);
logDen2 = logdenIndPred(fit.den2,fit.xmesh2,xtest);
xn = logDen1-logDen2;
