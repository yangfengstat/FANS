function [accuracy] = nodPredict(xtest,ytest, fit)
 
if(min(ytest)==0) %%%if y are 0/1, change it to 1/2
    ytest = ytest+1; 
end



logDen1 = logdenIndPred(fit.den1,fit.xmesh1,xtest);
logDen2 = logdenIndPred(fit.den2,fit.xmesh2,xtest);


xtestn = logDen1-logDen2;

xtestnn = [xtestn,xtest];


[~, accuracy1, ~] = svmpredict(ytest,xtest,fit.svm);
[~, accuracy2, ~] = svmpredict(ytest,xtestn,fit.nod_svm);
[~, accuracy3, ~] = svmpredict(ytest,xtestnn,fit.nod_svm_comb);

accuracy=[accuracy1(1),accuracy2(1),accuracy3(1)];