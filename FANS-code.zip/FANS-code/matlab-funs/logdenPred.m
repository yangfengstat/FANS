function [logIndDen, logDenPred]=logdenPred(den,xmesh,xtest)
[n, p] = size(xtest);
eps = 1e-10;
d = zeros(n,1);
for i=1:p
xi = xtest(:,i);
deni = den(:,i);
xmeshi = xmesh(:,i);
di = interp1(xmeshi,deni,xi,'linear','extrap');  
di(di<eps) = eps;
d = d+log(di);
end
logdenPred = d;
