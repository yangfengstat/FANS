function [error]=svmlinear2(x,y,xtest,ytest)
[x_scaled,scale_factor] = mapminmax(x');   

[bestc, ~, ~] = svmlincv(y,x_scaled');
cmd = ['-t 0  -c ',num2str(bestc),' -q'];

fit = svmtrain(y,x_scaled',cmd);

xtest_scaled = mapminmax('apply',xtest',scale_factor);

[~, accuracy, ~] = svmpredict(ytest, xtest_scaled', fit);
error = 1-accuracy(1)/100;
