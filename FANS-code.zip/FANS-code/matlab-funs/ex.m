p = 2;     % number of variables
n = 1000;      % number of observations
s0 = 2;      % number of nonzero mean differences

rho = 0.9;    % pairwise correlation coefficient
randSeed = 3; % setup the random seed to let the program repeatable



%% Generate data 
% First, we generate the means and the common covariance matrix for the two classes.
% Then, we generate the training and testing data from the true
% multivariate guassian distributions.

mu1 = zeros(p,1);
mu2 = zeros(p,1);

mu2(1:s0) = [1,-1];


Sigma = eqcor(p,rho);
 
rand('state', randSeed);
randn('state',randSeed);

nTrain  = n;
nTest   = n;

Y1Train = mvnrnd(repmat(mu1',nTrain,1),Sigma);
Y2Train = mvnrnd(repmat(mu2',nTrain,1),Sigma);

Y1Test  = mvnrnd(repmat(mu1',nTest,1),Sigma);
Y2Test  = mvnrnd(repmat(mu2',nTest,1),Sigma);


x = [Y1Train;Y2Train];
y = [zeros(n,1);ones(n,1)];


xtest = [Y1Test;Y2Test];
ytest = [zeros(n,1);ones(n,1)];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%Estimate univariate kernel density estimator

[den1,xmesh1] = Mkde(Y1Train);
[den2,xmesh2] = Mkde(Y2Train);

%%%%Estimate double exponential distribution for X_iX_j

x12 = Y1Train(:,1).*Y1Train(:,2);

[den3,xmesh3] = Mkde(x12);



m1.x12 = mean(x12);
b1 = sqrt(var(x12)/2);

x12 = Y2Train(:,1).*Y2Train(:,2);




[den4,xmesh4] = Mkde(x12);



m2.x12 = mean(x12);
b2 = sqrt(var(x12)/2);


%%%%Classify the testing data
%%%xtest 

d1 = denPred(den1,xmesh1,xtest);
d2 = denPred(den2,xmesh2,xtest);
x12test = xtest(:,1).*xtest(:,2);
cross1 = exp(-(abs(x12test-m1.x12))/b1)/2/b1;
cross2 = exp(-(abs(x12test-m2.x12))/b2)/2/b2;

d3 = denPred(den3,xmesh3,x12test);
d4 = denPred(den4,xmesh4,x12test);



f1 = d1.*cross1;
f2 = d2.*cross2;

g1 = d1.*d3;
g2 = d2.*d4;

e1 = sum((g1./g2<1)~=ytest)/2/n;
display(['general cross term density estimation ', num2str(e1)])



e2  = sum((f1./f2<1)~=ytest)/2/n;
display(['DE  cross term density estimation ', num2str(e2)])


e3 = sum((d1./d2<1)~=ytest)/2/n;
display(['independent density estimation ', num2str(e3)])


%addpath 'C:\Users\yangfeng\Documents\My Dropbox\Projects\ROAD\Penalized Classification\matlab-package\ROAD-code-v2';
addpath 'C:\Users\yangfeng\Documents\Dropbox\Projects\ROAD\Penalized Classification\matlab-package\ROAD-code-v2';
[ROADfit] = roadBatch(x, y, xtest, ytest, 0, 0);

display(['ROAD ', num2str(ROADfit.testError)])

[ldaobj] = lda(x,y,xtest,ytest);

display(['LDA ', num2str(ldaobj.testError)])

[IR.trainError,IR.testError]=IndError(Y1Train',Y2Train',Y1Test',Y2Test');
display(['IR ', num2str(mean(IR.testError))])



muDiff = (mu2-mu1)/2;

ORACLE.w = Sigma\muDiff;
mu1Train = mean(Y1Train)';
mu2Train = mean(Y2Train)';
SigmaTrain = 0.5*(cov(Y1Train)+cov(Y2Train));
muDiffTrain = (mu2Train-mu1Train)/2;
muAveTrain = (mu2Train+mu1Train)/2;

test1 = (Y1Test-repmat(muAveTrain', nTest, 1))*ORACLE.w >0 ;
test2 = (Y2Test-repmat(muAveTrain', nTest, 1))*ORACLE.w <0 ;
ORACLE.testError = mean([test1;test2]);

display(['ORACLE ', num2str(ORACLE.testError)])

