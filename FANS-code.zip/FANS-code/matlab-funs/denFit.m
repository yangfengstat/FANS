function [fit] = denFit(x,y)
addpath libsvm-3.11/matlab
 
if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1;
end

 x1 = x(y==1,:);  
 x2 = x(y==2,:);
 [fit.den1,fit.xmesh1] = Mkde(x1);
 [fit.den2,fit.xmesh2] = Mkde(x2);