function [logDen]=logdenIndPred(den,xmesh,xtest)
[n, p] = size(xtest);
eps = 1e-2;
d = zeros(n,p);
for i=1:p
xi = xtest(:,i);
deni = den(:,i);
xmeshi = xmesh(:,i);
%di = interp1(xmeshi,deni,xi,'spline','extrap');  
di = interp1(xmeshi,deni,xi,'linear','extrap');  
di(di<eps) = eps;
d(:,i) = log(di);
end
logDen = d;
