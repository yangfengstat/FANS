% This script is used to  calculate the misclassification rate of
% independence rule
function [trainError,testError]=IndError(Y1_train,Y2_train,Y1_test,Y2_test)
%Y1_train, Y1_test, Y1_test,Y2_test: Matrices, column 
% means sample, and row means feature , i.e. Gxn

n1_test=size(Y1_test,2);
n2_test=size(Y2_test,2);
n1_train=size(Y1_train,2);
n2_train=size(Y2_train,2);
mu1=mean(Y1_train');
mu2=mean(Y2_train');
Sig=(var(Y1_train')+var(Y2_train'))/2;
% D1=repmat(diag(diag(Sig)),1,n1_test);
% D2=repmat(diag(diag(Sig)),1,n2_test);

D1=repmat(Sig',1,n1_test);
D2=repmat(Sig',1,n2_test);


d1x=cumsum(((Y1_test-mu1'*ones(1,n1_test)).^2).*(D1.^(-1)),1);
d2x=cumsum(((Y1_test-mu2'*ones(1,n1_test)).^2).*(D1.^(-1)),1);
d1y=cumsum(((Y2_test-mu1'*ones(1,n2_test)).^2).*(D2.^(-1)),1);
d2y=cumsum(((Y2_test-mu2'*ones(1,n2_test)).^2).*(D2.^(-1)),1);

testError=mean([d1x>d2x d1y<=d2y],2);
D1=repmat(Sig',1,n1_train);
D2=repmat(Sig',1,n2_train);


d1x=cumsum(((Y1_train-mu1'*ones(1,n1_train)).^2).*(D1.^(-1)),1);
d2x=cumsum(((Y1_train-mu2'*ones(1,n1_train)).^2).*(D1.^(-1)),1);
d1y=cumsum(((Y2_train-mu1'*ones(1,n2_train)).^2).*(D2.^(-1)),1);
d2y=cumsum(((Y2_train-mu2'*ones(1,n2_train)).^2).*(D2.^(-1)),1);

trainError=mean([d1x>d2x d1y<=d2y],2);