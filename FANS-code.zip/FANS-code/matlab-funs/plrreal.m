function [label,response, responseTr, index]=plrreal(x,y,xtest,ytest, glmnetOptions,xtr)


stdx = std(x);
x = x./repmat(stdx,size(x,1),1);
xtest = xtest./repmat(stdx,size(xtest,1),1);

%[x indKeep] = perturb(x);
%xtest = xtest(:,indKeep);

fit = glmnet(x,y,'binomial',glmnetOptions);
cvfit = cvglmnet(x,y,5,[],'response','binomial',glmnetOptions,1);
[~,ind] = min(cvfit.cvm);
index = find(fit.beta(:,ind)~=0);
label = glmnetPredict(fit, 'class', xtest, fit.lambda(ind));
response = glmnetPredict(fit, 'response', xtest, fit.lambda(ind));
if(numel(xtr)>1)    
xtr = xtr./repmat(stdx,size(xtr,1),1);
%xtr = xtr(:,indKeep);
responseTr = glmnetPredict(fit, 'response', xtr, fit.lambda(ind));
else
responseTr = response; 
end
%accuracy = mean(ytest==label);


% b=glmfit(x,y-1,'binomial');
% glmpred = glmval(b,xtest,'logit');

