function [fit, fitCV, info]=snnb(x, y, xtest, ytest, nfold, pnum)
if (nargin < 5 )
    nfold = 5;
end
if (nargin < 6)
    pnum  = 2^10;
end

[fit] = nnbCV(x, y, nfold, pnum);
[fitCV] = snnbCV(fit);
%[errorCV, ind] = snnbCV(x, y, Id);
[info.errorList, info.errorFinal, info.ids] = snnbPredAll(x, y, xtest, ytest, fitCV);
[info.trainErrorList, info.trainErrorFinal, info.ids] = snnbPredAll(x, y, x, y, fitCV);
