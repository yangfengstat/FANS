function [errors]=RealRS(dataSetName, perc, randSeed)
if(nargin<3)
    randSeed=0;
end;
if(nargin<2)
    perc = 0.5;
end

rand('state', randSeed);
randn('state',randSeed);


data = dlmread(['datasets/',dataSetName, '.data.txt'],' ');
 
yall = data(:,end);

xall = data(:,1:(end-1));

[n p] = size(xall);
ind = randperm(n);

trInd = floor(n*perc);
teInd = trInd + floor(n*0.2);


trlab = ind(1: trInd);
telab = ind((trInd+1):teInd);

x = xall(trlab,:);
xtest = xall(telab,:);
y = yall(trlab);
ytest = yall(telab);

nx = (x-repmat(min(x),size(x,1),1))./repmat(max(x)-min(x),size(x,1),1);
nxtest = (xtest-repmat(min(x),size(xtest,1),1))./repmat(max(x)-min(x),size(xtest,1),1);
errors = nod(x,y,xtest,ytest);
%errors = nod(nx,y,nxtest,ytest);