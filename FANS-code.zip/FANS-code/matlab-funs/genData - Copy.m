function [x, y, xtest, ytest] = genData(type, randSeed, rho, n, p)
%%%type = 1: %%exponential decay
%%%type = 2: %%common correlations
%%%type = 3: %%common correlations, independent mixture of gaussian
%%%type = 4: %%independent mixture of norm and uniform v.s. independent
%%%uniform
%%%type = 5: %%within unit ball v.s. outside unit ball but inside unit box

%%%randSeed:  setup the random seed to let the program repeatable

if (nargin < 1)
    type = 1; 
end

if (nargin < 2)
    randSeed = 1;  
end

if (nargin < 3 )
    rho = 0.5;
end


rand('state', randSeed);
randn('state',randSeed);

if(nargin < 4)
    n=300;    % number of observations
end

if(nargin < 5)
    p=1000;   % number of variables
end

%p = 1000;     
%n = 300;      
s0 = 10;      % number of nonzero mean differences

nTrain  = n;
nTest   = n;


%display(['rho = ', num2str(rho)]);
%% Generate data 
% First, we generate the means and the common covariance matrix for the two classes.
% Then, we generate the training and testing data from the true
% multivariate guassian distributions.

mu1 = zeros(p,1);

mu2 = zeros(p,1);
mu2(1:s0) = ones(s0,1);

if(type <3)
if(type == 1) %%%exponential decay correlation
Sigma = exdecay(p,rho);
elseif(type ==2) %%%equal correlation
Sigma = eqcor(p,rho);
   % if(type ==3) 
%  Sigma = eqcor(p,rho);
%  mu2 = Sigma*mu2;
% end
end
mu2 = Sigma*mu2;
%mu2 = mu2/max(abs(mu2));
qqq = (mu2'/Sigma*mu2)/	5;
mu2 = mu2/qqq^0.5;
Y1Train = mvnrnd(repmat(mu1',nTrain,1),Sigma);
Y2Train = mvnrnd(repmat(mu2',nTrain,1),Sigma);

Y1Test  = mvnrnd(repmat(mu1',nTest,1),Sigma);
Y2Test  = mvnrnd(repmat(mu2',nTest,1),Sigma);
end


if (type == 3) %%norm mixture v.s. normal

mu2 = zeros(p,1);
mu2(1:s0) = 3*ones(s0,1);

mu11 = zeros(p,1);
mu12 = mu11;
mu12(1:s0) = 2*mu2(1:s0);

Sigma = eqcor(p,rho);

Y1Train1 = mvnrnd(repmat(mu11',nTrain,1),Sigma);

Y1Test1  = mvnrnd(repmat(mu11',nTest,1),Sigma);

Y1Train2 = mvnrnd(repmat(mu12',nTrain,1),Sigma);

Y1Test2  = mvnrnd(repmat(mu12',nTest,1),Sigma);

mix1 = repmat(random('binomial', 1,0.5,nTrain,1),1,p);
mix2 = repmat(random('binomial', 1,0.5,nTest,1),1,p);

Y1Train = Y1Train1 .* mix1 + Y1Train2.*(1-mix1);
Y1Test  = Y1Test1 .* mix2 + Y1Test2 .* (1-mix2);
Y2Train = mvnrnd(repmat(mu2',nTrain,1),Sigma);
Y2Test  = mvnrnd(repmat(mu2',nTest,1),Sigma);

elseif (type == 4) %%independent mixture of norm and uniform v.s. independent
%%%uniform
mu1 = zeros(p,1);
Sigma = exdecay(p,0);

mix1 = random('binomial', 1,0.5,nTrain,p);
mix2 = random('binomial', 1,0.5,nTest,p);

y11 = mvnrnd(repmat(mu1',nTrain,1),Sigma);

y12 = random('unif',-1,1,nTrain,p);

y21 = mvnrnd(repmat(mu1',nTest,1),Sigma);

y22 = random('unif',-1,1,nTest,p);

Y1Train = mix1.*y11+(1-mix1).*y12;
Y1Test  = mix2.*y21+(1-mix2).*y22;

Y2Train = y12;

Y2Test  = y22;
  
elseif (type ==5) %%%unit ball v.s. unit square\unit ball
% y1 = random('unif',-1,1,2*n,2);
% ynorm = sum(y1.^2, 2);
% y11 = y1(1:n,:);
% y12 = y1((n+1):(2*n),:);
% ynorm1 = ynorm(1:n);
% ynorm2 = ynorm((n+1):(2*n),:);
% Y1Train = y11(ynorm1<1,:);

mu1 = zeros(p,1);
Sigma = exdecay(p,0);

y11 = mvnrnd(repmat(mu1',2*n,1),Sigma);

r = sum(y11.^2,2);
y12 = (random('unif',0,1,2*n,1)).^(1/p);

y1 = y11./repmat(r.^0.5./y12,1,size(y11,2));

Y1Train = y1(1:nTrain,:);
Y1Test = y1((nTrain+1):(2*n),:);

y2 = zeros(2*n,p);
NotInBall = (sum(y2.^2,2)>1); 

while(sum(NotInBall)<(2*n))
y2(~NotInBall,:) = random('unif',-1,1,2*n-sum(NotInBall),p);
NotInBall = (sum(y2.^2,2)>1); 
end

Y2Train = y2(1:nTrain,:);
Y2Test = y2((nTrain+1):(2*n),:);
elseif (type == 6) %%norm mixture v.s. normal

mu2 = zeros(p,1);
mu2(1:s0) = 7*ones(s0,1);

mu11 = zeros(p,1);
mu12 = mu11;
mu12(1:s0) = 2*mu2(1:s0)-4;
Sigma = eqcor(p,rho);

Y1Train1 = mvnrnd(repmat(mu11',nTrain,1),Sigma);

Y1Test1  = mvnrnd(repmat(mu11',nTest,1),Sigma);

Y1Train2 = mvnrnd(repmat(mu12',nTrain,1),Sigma);

Y1Test2  = mvnrnd(repmat(mu12',nTest,1),Sigma);

mix1 = random('binomial', 1,0.5,nTrain,p);
mix2 = random('binomial', 1,0.5,nTest,p);

Y1Train = Y1Train1 .* mix1 + Y1Train2.*(1-mix1);
Y1Test  = Y1Test1 .* mix2 + Y1Test2 .* (1-mix2);

Y2Train = mvnrnd(repmat(mu2',nTrain,1),Sigma);
Y2Test  = mvnrnd(repmat(mu2',nTest,1),Sigma);


end
x = [Y1Train;Y2Train];
y = [ones(n,1);2*ones(n,1)];


xtest = [Y1Test;Y2Test];
ytest = [ones(n,1);2*ones(n,1)];