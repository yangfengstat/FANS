function [errors]=analyzeReal(dataSetName, nfold, pnum)
if (nargin<2 )
    nfold = 5;
end
if (nargin<3)
    pnum = 2^8;
end

traindata = dlmread([dataSetName, '_train.csv'],',');
testdata = dlmread([dataSetName,'_test.csv'],',');    
data = [traindata ;testdata];
trlab = traindata(:,end);
telab = testdata(:,end);
data = data(:,1:(end-1));
n1Train = sum(trlab==0);
n2Train = sum(trlab==1);
n1Test = sum(telab==0);
n2Test = sum(telab==1);
if(n1Train+n2Train+n1Test+n2Test~=size(data,1))
    error('The labeling has problem, must be 0 for the first class and 1 for the second class');
end

[n p] = size(data);
display(['n=',num2str(n),', p=',num2str(p)]);
dataMean = mean(data,2);
dataStd = std(data,0,2);

%normData = (data-repmat(dataMean,1,p))./repmat(dataStd,1,p);

normData = data;

 nTrain = n1Train + n2Train;
 nTest = n1Test + n2Test;
 
 x = normData(1:nTrain,:);
 y = trlab;
 xtest = normData((nTrain+1):end, :);
 ytest = telab;
% 
% 
% Y1Train = normData(1:n1Train,:);
% Y2Train = normData((n1Train+1):nTrain, :);
% 
% Y1Test = normData((nTrain+1):(nTrain+n1Test),:);
% Y2Test = normData((n-n2Test+1):n,:);
% 
% x = [Y1Train;Y2Train];
% y = [zeros(n1Train,1);ones(n2Train,1)];
% 
% 
% xtest = [Y1Test;Y2Test];
% ytest = [zeros(n1Test,1);ones(n2Test,1)];

errors = nod(x,y,xtest,ytest);