function [den,xmesh]=Mkde(x, pnum)
if (nargin<2 )
    pnum = 2^7;
end
n=2^ceil(log2(pnum)); % round up n to the next power of 2;
p = size(x,2);
xmesh = zeros(n, p);
den = zeros(n, p);
for i=1:p
xi = x(:,i);
%[~,den(:,i),xmesh(:,i),~] = kde(xi, n); 
[den(:,i),xmesh(:,i)] = ksdensity(xi, 'npoints',n);  
% lo = den(:,i)<0.01;
% hi = den(:,i)>100;
% den(lo,i)=0.01;
% den(hi,i)=100;
end