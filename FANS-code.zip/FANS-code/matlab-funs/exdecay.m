function [Sigma]=exdecay(p,rho)
% p: number of features-- the length of error vector
a=repmat(1:p,p,1);
Sigma = rho.^(abs(a-a'));
