function [yPred]=snnbPred(x, y, xtest, index)
x = x(:,index); %%%only need to variables in index
xtest = xtest(:,index);

if(min(y)==1) %%%if y=1/2, change it to 0/1
    y = y - 1;
end

x1 = x(y==0,:);  
x2 = x(y==1,:);

[den1,xmesh1] = Mkde(x1);
[den2,xmesh2] = Mkde(x2);

[logDen1]=sum(logdenIndPred(den1,xmesh1,xtest),2);
[logDen2]=sum(logdenIndPred(den2,xmesh2,xtest),2);
yPred = (logDen1<logDen2);