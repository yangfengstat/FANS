function [ind] = drscreen(x,y, fdr)
%screening by density ratio

if(nargin < 3)
    fdr = 0.01;
end

p = size(x,2);

if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1;
end
ind1 = find(y==1);
ind2 = find(y==2);

n1 = length(ind1);
n2 = length(ind2);
[fit] = denFit(x,y);
[xtr] = TransFeature(x,fit);
xvar = var(xtr,1);
xcor = abs(xtr'*y);
%%use corr
 rand('state', 1);
randn('state',1);
p11 = randsample(n1, ceil(n1/2));
p12 = randsample(n2, ceil(n2/2));
yperm = y;
yperm(p11) = 2;
yperm(p12+n1) = 1;
 [fitperm] = denFit(x, yperm);
[xtrperm] = TransFeature(x,fitperm);
xvarperm = var(xtrperm,1);  

xcorperm = abs(xtrperm'*yperm);
indvar = find(xvar>quantile(xvarperm,1-fdr))
ind = find(xcor>quantile(xcorperm,1-fdr))


indvar = find(xvar>quantile(xvarperm,1))
ind = find(xcor>quantile(xcorperm,1))
ind=find(xcor>quantile(xcorperm,1-fdr));
