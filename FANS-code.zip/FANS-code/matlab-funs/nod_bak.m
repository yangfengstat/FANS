function [error] = nod(x,y,xtest,ytest)
addpath libsvm-3.11/matlab
% if (nargin < 5 )
%     type = 1; %%% type=1 means using penalized logistic regression in the second step
% end

%%%type = 2 represents using SVM in the second step

if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1; 
    ytest = ytest+1;
end

x1 = x(y==1,:);  
x2 = x(y==2,:);


[den1,xmesh1] = Mkde(x1);
[den2,xmesh2] = Mkde(x2);
logDen1 = logdenIndPred(den1,xmesh1,x);
logDen2 = logdenIndPred(den2,xmesh2,x);

xn = logDen1-logDen2;

logDen1 = logdenIndPred(den1,xmesh1,xtest);
logDen2 = logdenIndPred(den2,xmesh2,xtest);


xtestn = logDen1-logDen2;

fit = glmnet(x,y,'binomial');
cvfit = cvglmnet(x,y,5,[],'response','binomial',glmnetSet,0);
[~,ind] = min(cvfit.cvm);
error.plr = mean(ytest~=glmnetPredict(fit, 'class', xtest, fit.lambda(ind)));


fit2 = glmnet(xn,y,'binomial');
cvfit2 = cvglmnet(xn,y,5,[],'response','binomial',glmnetSet,0);
[~,ind] = min(cvfit2.cvm);
error.nod_plr = mean(ytest~=glmnetPredict(fit2, 'class', xtestn, fit2.lambda(ind)));

xnn = [xn,x];
xtestnn = [xtestn, x];
fit3 = glmnet(xnn,y,'binomial');
cvfit3 = cvglmnet(xnn,y,5,[],'response','binomial',glmnetSet,0);
[~,ind] = min(cvfit3.cvm);
error.nod_plr_comb = mean(ytest~=glmnetPredict(fit3, 'class', xtestnn, fit3.lambda(ind)));

error.svm = svmlinear(x,y,xtest,ytest);
error.nod_svm = svmlinear(xn,y,xtestn,ytest);
error.nod_svm_comb = svmlinear(xnn,y,xtestnn,ytest);
% 
% error.svm_lin = svmlin(x,y,xtest,ytest);
% error.nod_svm_lin = svmlin(xn,y,xtestn,ytest);
% error.nod_svm_comb_lin = svmlin(xnn,y,xtestnn,ytest);

error.svm_gaussian=svmgaussian(x,y,xtest,ytest);
error.nod_svm_gaussian=svmgaussian(xn,y,xtestn,ytest);
error.nod_svm_comb_gaussian=svmgaussian(xnn,y,xtestnn,ytest);
% svmStruct = svmtrain(y, x,'-q');
% %svmStruct = svmtrain(y, x,'-t 0 -q');
% 
% [~, accuracy, ~] = svmpredict(ytest, xtest, svmStruct);
% error.svm = 1-accuracy(1)/100;
% 
% svmStruct = svmtrain(y, xn,'-q');
% %svmStruct = svmtrain(y, x,'-t 0 -q');
% 
% [~, accuracy, ~] = svmpredict(ytest, xtestn, svmStruct);
% error.nod_svm = 1-accuracy(1)/100;
% 
% svmStruct = svmtrain(y, xnn,'-q');
% %svmStruct = svmtrain(y, x,'-t 0 -q');
% 
% [~, accuracy, ~] = svmpredict(ytest, xtestnn, svmStruct);
% error.nod_svm_comb = 1-accuracy(1)/100;

[ROADfit] = roadBatch(x, y-1, xtest, ytest-1, 0, 0);

error.ROAD = ROADfit.testError;

[ldaobj] = lda(x,y-1,xtest,ytest-1);

error.LDA = ldaobj.testError;

Y1Train = x(y==1,:);
Y2Train = x(y==2,:);
Y1Test = xtest(ytest==1,:);
Y2Test = xtest(ytest==2,:);
[FAIR.num, FAIR.trainError, FAIR.testError, IR.trainError, IR.testError, Tvalue, IT] = fair(Y1Train, Y2Train, Y1Test, Y2Test);
error.NB = mean(IR.testError);
error.FAIR = mean(FAIR.testError);
% %errorlist = [mean(yPred~=ytest), ROADfit.testError, ldaobj.testError, mean(IR.testError),FAIR.testError, ORACLE.testError];
% display(['IR ', num2str(mean(IR.testError))])
% display(['FAIR ', num2str(mean(FAIR.testError))])
