function [label,accuracy, prob]=svmlinear(x,y,xtest,ytest)
[x_scaled,scale_factor] = mapminmax(x');   

%bestc = 1;
[bestc, ~, ~] = svmlincv(y,x_scaled');
cmd = ['-t 0  -c ',num2str(bestc),' -b 1 -q'];

fit = svmtrain(y,x_scaled',cmd);

xtest_scaled = mapminmax('apply',xtest',scale_factor);

[label, accuracy, prob2] = svmpredict(ytest, xtest_scaled', fit, '-b 1');
prob = prob2(:,fit.Label==2);


