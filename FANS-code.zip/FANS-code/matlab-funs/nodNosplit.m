function [fans,fans2] = nodNosplit(x,y, xtest, ytest, lammin)
%addpath libsvm-3.11/matlab
t0 = cputime;
if(nargin < 5)
    lammin = 0;
end
p = size(x,2);

if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1;
    ytest = ytest+1;
end
ntest = size(ytest,1);
N = size(x,1);
ind1 = find(y==1);
ind2 = find(y==2);
n1 = length(ind1);
n2 = length(ind2);
p11 = randsample(n1, ceil(n1/2));
p12 = randsample(n2, ceil(n2/2));
p1 = [ind1(p11); ind2(p12)];
p2 = setdiff(1:N,p1);
[fit] = denFit(x(p1,:),y(p1));
[xn] = TransFeature(x(p2,:), fit);
[xtestn] = TransFeature(xtest, fit);
[xnn] = [xn,x(p2,:)];
[xtestnn] = [xtestn, xtest];
%    [label1(:,i),prob1(:,i)] =svmgaussian(xn,y(~which),xtestn,ytest);
%    [label2(:,i),prob2(:,i)] =svmgaussian(xnn,y(~which),xtestnn,ytest);
[fans.label,fans.prob,~,fans.set] = plr(xn,y(p2),xtestn,ytest, lammin);
[fans2.label,fans2.prob,~,fans2.set] = plr(xnn,y(p2),xtestnn,ytest, lammin);

fans.error = mean(fans.label~=ytest);
fans2.error = mean(fans2.label~=ytest);
fans.size = length(fans.set);
fans2.size = length(fans2.set);

fans.time = cputime-t0;
fans2.time = fans.time;