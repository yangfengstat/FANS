function [fairNum, fairTrainError, fairTestError, irTrainError, irTestError, Tvalue, IT] = fair(Y1Train, Y2Train, Y1Test, Y2Test)
    n1_train = size(Y1Train, 1);
    n2_train = size(Y2Train, 1);
    p = size(Y1Train, 2);
    T=(mean(Y1Train)-mean(Y2Train))./(std(Y1Train).^2/n1_train+std(Y2Train).^2/n2_train).^(1/2);
    %plot(abs(T))
    [Tvalue,IT]=sort(abs(T),'descend');
    %T_true=abs(muDiff)./sqrt(diag(Sigma)');
    
    %[~,IT_true]=sort(T_true,'descend');
    %plot(B)
    fairNum=opm0(Y1Train(:,IT)',Y2Train(:,IT)');% estimate of the optimal truncation point
    
    Y1Train=Y1Train';
    Y1Test=Y1Test';
    Y2Train=Y2Train';
    Y2Test=Y2Test';
    [fullTrainError,fullTestError]=IndError(Y1Train(IT,:),Y2Train(IT,:),Y1Test(IT,:),Y2Test(IT,:));
    fairTrainError=fullTrainError(fairNum);
    fairTestError=fullTestError(fairNum); 
    irTrainError=fullTrainError(p);   
    irTestError=fullTestError(p);
    
   % EDC_errorx=EDCError(Y1Train(IT,:),Y2Train(IT,:),Y1Test(IT,:),Y2Test(IT,:));
   % EDC_errorx_trunc=EDC_errorx(m0);
    %EDC_errorx_trunc1(tt)=EDC_errorx(m0hat(tt)+1,tt);
    
   % EDC_errorx_true=EDCError(Y1Train(IT_true,:),Y2Train(IT_true,:),Y1Test(IT_true,:),Y2Test(IT_true,:));
    
        %%%%%%%%%%%%%%%%%%%% Project the data to a particular direction %%%%%%%%%%
%     a=randn(p,1);
%     a=a/norm(a,2);
%     
%     Y1a_train=a'*Y1Train;
%     Y2a_train=a'*Y2Train;
%     
%     Y1a_test=a'*Y1Test;
%     Y2a_test=a'*Y2Test;
%     
%     
%     errorx_a_true=IndError(Y1a_train,Y2a_train,Y1a_test,Y2a_test);