function [errorList, errorFinal, id]=snnbPredAll(x, y, xtest, ytest, fit)
index = fit.IdDetail;
%index = fit.IdLik;
x = x(:,index); %%%only need to variables in index
xtest = xtest(:,index);

%errorCV = fit.logLikRatio;
errorCV = fit.errorCVDetail;
[minErrorCV, id] = min(errorCV);

if(min(y)==1) %%%if y=1/2, change it to 0/1
    y = y - 1;
end

x1 = x(y==0,:);  
x2 = x(y==1,:);

[den1,xmesh1] = Mkde(x1,fit.pnum);
[den2,xmesh2] = Mkde(x2,fit.pnum);

[logDen1]=cumsum(logdenIndPred(den1,xmesh1,xtest),2);
[logDen2]=cumsum(logdenIndPred(den2,xmesh2,xtest),2);
yPred = (logDen1<logDen2);
errorList = sum(yPred~=repmat(ytest,1, size(yPred,2)));

errorFinal = errorList(id);