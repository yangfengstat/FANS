%% This function is used to estimate the optimal number of features if 
% we use the independence rule. 
% 
function [m0]=opm0(Y1Train,Y2Train,nn)

% n: scalar, sample size of two classes (n1=n2=n)
% Y1Train,Y2Train: permulated training sample (permulated according to
%                    the order of Tsort)

n=size(Y1Train,1);

if(nargin < 3) 
    nn=min(60,n);
end
mu1=mean(Y1Train');
mu2=mean(Y2Train');
muDiff = mu1-mu2; 

Tsort=(mu1-mu2).^2./((var(Y1Train')+var(Y2Train'))/2);
temp=cumsum(Tsort);
p=length(temp);

%temp1=[Y1Train, Y2Train]'-[repmat(mu1,n,1); repmat(mu2,n,1)];
for i=1:nn
        Sig0=(corr(Y1Train(1:i,:)')+corr(Y2Train(1:i,:)'))/2; %permulated correlation matrix. nu x nu.  
        if(sum(isnan(Sig0(:)))>0) 
            break;
        end
    lambda(i)= max(eig(Sig0));
end

ni = length(lambda);
W=(n*(temp.^2)./(1:p))./(1+n*temp./(1:p));
[~, rankW]=sort(W(1:ni)./lambda,'descend');

% T2 = cumsum(Tsort);
% 
% W2 = T2.^2./(2*(1:p)/n+T2);
% 
% [temp2, rankW2]=sort(W2, 'descend');

m0=rankW(1);

% m1=rankW2(1);