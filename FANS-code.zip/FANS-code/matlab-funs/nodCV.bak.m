function [error, nodnum, ypred, ptime] = nodCV(x,y, xtest, ytest, nfolds, lammin)
%addpath libsvm-3.11/matlab
t0 = cputime;
if(nargin < 6)
    lammin = 0;
end
 if (nargin < 5 )
     nfolds = 2; 
 end
p = size(x,2);

if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1;
    ytest = ytest+1;
end
ntest = size(ytest,1);
N = size(x,1);

foldid = randsample([repmat(1:nfolds,1,floor(N/nfolds)) 1:mod(N,nfolds)],N);
%label1 = zeros(ntest,nfolds);
%label2 = zeros(ntest,nfolds);
label3 = zeros(ntest,nfolds);
label4 = zeros(ntest,nfolds);
%prob1 = zeros(ntest,nfolds);
%prob2 = zeros(ntest,nfolds);
prob3 = zeros(ntest,nfolds);
prob4 = zeros(ntest,nfolds);
% prob5 = zeros(ntest,nfolds);
% prob6 = zeros(ntest,nfolds);
set1=[];
set2=[];
for i=1:nfolds
    which = (foldid==i);
    [fit] = denFit(x(which,:),y(which));
    [xn] = TransFeature(x(~which,:), fit);
    [xtestn] = TransFeature(xtest, fit);
    [xnn] = [xn,x(~which,:)];
    [xtestnn] = [xtestn, xtest];
%    [label1(:,i),prob1(:,i)] =svmgaussian(xn,y(~which),xtestn,ytest);    
%    [label2(:,i),prob2(:,i)] =svmgaussian(xnn,y(~which),xtestnn,ytest);   
    [label3(:,i),prob3(:,i),~,index1{i}] = plr(xn,y(~which),xtestn,ytest, lammin);
    [label4(:,i),prob4(:,i),~,index2{i}] = plr(xnn,y(~which),xtestnn,ytest, lammin);
    set1 = union(set1,index1{i});
    set2 = union(set2, index2{i});
end
set2 = union(set2(set2<=p), set2(set2>p)-p);
% error(1) = mean(median(label1')~=ytest');
% error(2) = mean(median(label2')~=ytest');
 error(3) = mean(median(label3')~=ytest');
 error(4) = mean(median(label4')~=ytest');
 error(1) = mean(((mean(prob3')>0.5)+1)~=ytest');
 error(2) = mean(((mean(prob4')>0.5)+1)~=ytest');
 ypred = ((mean(prob3')>0.5)+1);
nodnum(1) = length(set1);
nodnum(2) = length(set2);
ptime = cputime-t0;
%error(1) = mean(((mean(prob1')>0.5)+1)~=ytest');
% %error(2) = mean(((mean(prob2')>0.5)+1)~=ytest');
% error(3) = mean(((mean(prob3')>0.5)+1)~=ytest');
% error(4) = mean(((mean(prob4')>0.5)+1)~=ytest');
% error(5) = mean(((mean(prob5')>0.5)+1)~=ytest');
% error(6) = mean(((mean(prob6')>0.5)+1)~=ytest');