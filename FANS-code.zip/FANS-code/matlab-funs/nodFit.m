function [fit] = nodFit(x,y, cost)
 if (nargin < 3 )
     cost = 1; 
 end

if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1; 
end



x1 = x(y==1,:);  
x2 = x(y==2,:);


[den1,xmesh1] = Mkde(x1);
[den2,xmesh2] = Mkde(x2);
logDen1 = logdenIndPred(den1,xmesh1,x);
logDen2 = logdenIndPred(den2,xmesh2,x);


xn = logDen1-logDen2;

xnn = [xn,x];

cmd = ['-t 0  -c ',num2str(cost),' -q'];

fit.svm = svmtrain(y,x,cmd);

fit.nod_svm = svmtrain(y,xn,cmd);

fit.nod_svm_comb = svmtrain(y,xnn,cmd);

fit.den1=den1;
fit.den2=den2;
fit.xmesh1=xmesh1;
fit.xmesh2=xmesh2;