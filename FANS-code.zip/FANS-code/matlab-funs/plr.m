function [label,response, accuracy, index]=plr(x,y,xtest,ytest,lammin)
options = glmnetSet();
if(lammin~=0)
    options.lambda_min=lammin;
end
fit = glmnet(x,y,'binomial');
cvfit = cvglmnet(x,y,'binomial',[],[],5);
[~,ind] = min(cvfit.cvm);
index = find(fit.beta(:,ind)~=0);
label = glmnetPredict(fit, xtest, fit.lambda(ind),'class');
response = glmnetPredict(fit, xtest, fit.lambda(ind),'response');
accuracy = mean(ytest==label);


% b=glmfit(x,y-1,'binomial');
% glmpred = glmval(b,xtest,'logit');


