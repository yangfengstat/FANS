function [error, nodnum, ypred, ptime] = nodCVScreen(x,y, xtest, ytest, nfolds, lammin)
%addpath libsvm-3.11/matlab
t0 = cputime;
if(nargin < 6)
    lammin = 0;
end
 if (nargin < 5 )
     nfolds = 10; 
 end
p = size(x,2);

if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1;
    ytest = ytest+1;
end
ntest = size(ytest,1);
N = size(x,1);
[ind] = drscreen(x,y,0.01);


%label1 = zeros(ntest,nfolds);
%label2 = zeros(ntest,nfolds);
label3 = zeros(ntest,nfolds);
label4 = zeros(ntest,nfolds);
label5 = zeros(ntest,nfolds);
%prob1 = zeros(ntest,nfolds);
%prob2 = zeros(ntest,nfolds);
prob3 = zeros(ntest,nfolds);
prob4 = zeros(ntest,nfolds);
prob5 = zeros(ntest,nfolds);
% prob6 = zeros(ntest,nfolds);
set1=[];
set2=[];
ind1 = find(y==1);
ind2 = find(y==2);
n1 = length(ind1);
n2 = length(ind2);
p11 = zeros(nfolds,ceil(n1/2));

%%%%%%%%%%evenly split double the split!!!

%%%%%%%%%%%%%%%

p12 = zeros(nfolds,ceil(n2/2));
for i=1:nfolds   
    rand('state', i);
    randn('state',i);
    p11(i,:) = randsample(n1, ceil(n1/2));
    p12(i,:) = randsample(n2, ceil(n2/2));
end

for i=1:(2*nfolds)
    display(['Nod CV ', num2str(i),' of ', num2str(2*nfolds)]);
    if(mod(i,2)~=0)
    p1 = [ind1(p11(ceil(i/2),:)); ind2(p12(ceil(i/2),:))];   
    else
    p1 = [ind1(setdiff(1:n1, p11(ceil(i/2),:))); ind2(setdiff(1:n2,p12(ceil(i/2),:)))];
    end
     p2 = setdiff(1:N,p1);
    [fit] = denFit(x(p1,ind),y(p1));
    [xn] = TransFeature(x(p2,ind), fit);
    [xtestn] = TransFeature(xtest(:,ind), fit);
    [xnn] = [xn,x(p2,:)];
    [xtestnn] = [xtestn, xtest];
    xn2 = [xn, x(p2,ind)];
    xtestn2 = [xtestn, xtest(:,ind)];
%    [label1(:,i),prob1(:,i)] =svmgaussian(xn,y(~which),xtestn,ytest);    
%    [label2(:,i),prob2(:,i)] =svmgaussian(xnn,y(~which),xtestnn,ytest);   
    [label3(:,i),prob3(:,i),~,index1{i}] = plr(xn,y(p2),xtestn,ytest, lammin);
    [label4(:,i),prob4(:,i),~,index2{i}] = plr(xnn,y(p2),xtestnn,ytest, lammin);
    [label5(:,i),prob5(:,i),~,index3{i}] = plr(xn2,y(p2),xtestn2,ytest, lammin);
    set1 = union(set1,index1{i});
    set2 = union(set2, index2{i});
end
set2 = union(set2(set2<=p), set2(set2>p)-p);
% error(1) = mean(median(label1')~=ytest');
% error(2) = mean(median(label2')~=ytest');
 error(4) = mean(median(label3')~=ytest');
 error(5) = mean(median(label4')~=ytest');
 error(1) = mean(((mean(prob3')>0.5)+1)~=ytest');
 error(2) = mean(((mean(prob5')>0.5)+1)~=ytest');
 error(3) = mean(((mean(prob4')>0.5)+1)~=ytest');
 ypred = ((mean(prob3')>0.5)+1);
nodnum(1) = length(set1);
nodnum(2) = length(set2);
ptime = cputime-t0;
%error(1) = mean(((mean(prob1')>0.5)+1)~=ytest');
% %error(2) = mean(((mean(prob2')>0.5)+1)~=ytest');
% error(3) = mean(((mean(prob3')>0.5)+1)~=ytest');
% error(4) = mean(((mean(prob4')>0.5)+1)~=ytest');
% error(5) = mean(((mean(prob5')>0.5)+1)~=ytest');
% error(6) = mean(((mean(prob6')>0.5)+1)~=ytest');