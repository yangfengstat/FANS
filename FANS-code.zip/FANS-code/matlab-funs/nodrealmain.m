%%sequnce: PLR, NOD, NOD2, SVM, NODP,NODP2, ROAD, LDA, NB, FAIR
function [error, num, time] = nodrealmain(x,y,xtest,ytest)
addpath libsvm-3.11/matlab
% if (nargin < 5 )
%     type = 1; %%% type=1 means using penalized logistic regression in the second step
% end

%%%type = 2 represents using SVM in the second step

if(min(y)==0) %%%if y are 0/1, change it to 1/2
    y = y+1; 
    ytest = ytest+1;
end


fit = glmnet(x,y,'binomial');
cvfit = cvglmnet(x,y,5,[],'response','binomial',glmnetSet,0);
[~,ind] = min(cvfit.cvm);
num.plr = fit.df(ind);
error.plr = mean(ytest~=glmnetPredict(fit, 'class', xtest, fit.lambda(ind)));
error.plrtrain = mean(y~=glmnetPredict(fit, 'class', x, fit.lambda(ind)));



[errors, nodnum, ~, ptime] = nodCVRealScreen(x,y, xtest, ytest);
num.nods = nodnum(1);
num.nods2 = nodnum(2);
time.nods = ptime;
error.nods_test=errors(1);
error.nods_test2=errors(2);
error.nods_train = errors(3);
error.nods_train2 = errors(4);
error.nods_test3 = errors(5);


[errors, nodnum, ~, ptime] = nodCVreal(x,y, xtest, ytest);
num.nod = nodnum(1);
num.nod2 = nodnum(2);
time.nod = ptime;
error.nod_test=errors(1);
error.nod_test2=errors(2);
error.nod_train = errors(3);
error.nod_train2 = errors(4);


errors

t0 = cputime;
[~,error.svm] = svmgaussian(x,y,xtest,ytest);
time.svm = cputime-t0;

t0 = cputime;
[ROADfit] = roadBatch(x, y-1, xtest, ytest-1, 0, 0);
time.ROAD = cputime-t0;
num.road = ROADfit.num;
error.ROAD = ROADfit.testError;
error.ROADtrain = ROADfit.trainError;
[ldaobj] = lda(x,y-1,xtest,ytest-1);

error.LDA = ldaobj.testError;

Y1Train = x(y==1,:);
Y2Train = x(y==2,:);
Y1Test = xtest(ytest==1,:);
Y2Test = xtest(ytest==2,:);
[FAIR.num, FAIR.trainError, FAIR.testError, IR.trainError, IR.testError, Tvalue, IT] = fair(Y1Train, Y2Train, Y1Test, Y2Test);
num.fair = FAIR.num;
error.NB = mean(IR.testError);
error.FAIR = mean(FAIR.testError);
error.FAIRtrain = mean(FAIR.trainError);
% %errorlist = [mean(yPred~=ytest), ROADfit.testError, ldaobj.testError, mean(IR.testError),FAIR.testError, ORACLE.testError];
% display(['IR ', num2str(mean(IR.testError))])
% display(['FAIR ', num2str(mean(FAIR.testError))])
