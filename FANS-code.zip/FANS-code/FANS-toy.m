%%FANS example
randSeed = 1;
n = 300;
p = 1000;

addpath 'matlab-funs/'
addpath 'glmnet_matlab'
addpath libsvm-3.11/matlab

display(['randSeed=', num2str(randSeed)]);

type = 1;
rho = 0.5;

[x, y, xtest, ytest] = genData(type, randSeed, rho, n, p);

[errors, sizes, ~, ptime] = FANS(x,y, xtest, ytest, 3);

errors
sizes

%%errors: contains the test classification error of FANS and FANS2.
%%error(1): FANS with mean probability
%%error(2): FANS2 with mean probability
%%error(3): FANS with majority vote
%%error(4): FANS2 with majority vote
%%sizes: contain the number of variables recruited by FANS and FANS2.
%%sizes(1): number of variables of FANS
%%sizes(2): number of variables of FANS2
 



